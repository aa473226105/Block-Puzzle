﻿public class PrefKeys
{
    public const string CURRENCY = "coins";
    public const string SAVE_VERSION_CODE = "save_version_code";
    public const string CURRENT_LEVEL = "current_level";
}
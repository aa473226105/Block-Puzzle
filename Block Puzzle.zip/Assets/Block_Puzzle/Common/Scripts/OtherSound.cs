﻿using UnityEngine;

public class OtherSound : MonoBehaviour
{
    public AudioClip[] audioClips;
    public enum Type { CoinCollected };
}
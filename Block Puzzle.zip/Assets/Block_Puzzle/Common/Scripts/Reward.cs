﻿namespace Superpow
{
    public class Reward
    {
        public string type;
        public int number;
        public bool received;
    }
}
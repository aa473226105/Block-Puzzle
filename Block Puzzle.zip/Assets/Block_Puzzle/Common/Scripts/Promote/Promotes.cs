﻿using System.Collections.Generic;
public class Promotes
{
    public List<Promote> promotes { get; set; }
}
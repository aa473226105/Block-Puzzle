﻿public class Promote
{
    public PromoteType type { get; set; }
    public string package { get; set; }
    public string featureUrl { get; set; }
    public int featureWidth { get; set; }
    public int featureHeight { get; set; }
    public string message { get; set; }
    public RewardType rewardType { get; set; }
    public int rewardValue { get; set; }
    public string rewardMessage { get; set; }
}
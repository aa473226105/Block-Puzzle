﻿using UnityEngine;

public class ButtonSound : MonoBehaviour
{
    public AudioClip[] audioClips;
    public enum Type { Def, Gratz };
}
﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class BrickPart : MonoBehaviour {
    [HideInInspector]
    public Vector2 pos;
    public Image image;
    public GameObject frame;
}

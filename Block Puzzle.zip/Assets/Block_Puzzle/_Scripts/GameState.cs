﻿public class GameState
{
    
}
﻿using UnityEngine;
using System.Collections;

public class Const
{
    public static int NUM_WORLD = 4;
    public static string[] WORLD_NAMES = { "初学者", "高级", "大师", "专家" };
    public static int[] UNLOCK_STARS = { 0, 30, 60, 90, 120, 150, 180, 210 };
}
